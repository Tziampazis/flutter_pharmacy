import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import 'Cart_Screen.dart';



class eyeCareScreen extends StatefulWidget {
  static const String id = 'eyeCare_screen';
  @override
  State<StatefulWidget> createState() =>eyeCareScreenState();
}

class eyeCareScreenState extends State<eyeCareScreen> {

  IconData _backIcon() {
    switch (Theme.of(context).platform) {
      case TargetPlatform.android:
      case TargetPlatform.fuchsia:
        return Icons.arrow_back;
      case TargetPlatform.iOS:
        return Icons.arrow_back_ios;
    }
    assert(false);
    return null;
  }

  List<StaggeredTile> _staggeredTiles = const <StaggeredTile>[
    const StaggeredTile.count(1, 1.3),
    const StaggeredTile.count(1, 1.3),
    const StaggeredTile.count(1, 1.3),
    const StaggeredTile.count(1, 1.3),
    const StaggeredTile.count(1, 1.3),
    const StaggeredTile.count(1, 1.3),

  ];

  List<Widget> _tiles = const <Widget>[
    const _Example01Tile(Colors.green, Icons.widgets),
    const _Example01Tile(Colors.lightBlue, Icons.wifi),
    const _Example01Tile(Colors.amber, Icons.panorama_wide_angle),
    const _Example01Tile(Colors.brown, Icons.map),
    const _Example01Tile(Colors.deepOrange, Icons.send),
    const _Example01Tile(Colors.indigo, Icons.airline_seat_flat),
//    const _Example01Tile(Colors.red, Icons.bluetooth),
//    const _Example01Tile(Colors.pink, Icons.battery_alert),
//    const _Example01Tile(Colors.purple, Icons.desktop_windows),
//    const _Example01Tile(Colors.blue, Icons.radio),
  ];


  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    final ThemeData theme = Theme.of(context);

    return new Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(_backIcon()),
          alignment: Alignment.centerLeft,
          color: Colors.green,
          tooltip: 'Back',
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        backgroundColor: Colors.white,
        title: Text('Eye Care',style: TextStyle(color: Colors.lightGreen),),
        iconTheme: new IconThemeData(color: Colors.green),
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.shopping_cart,color: Colors.lightGreen,),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Cart_screen()));
              }
          ),
        ],
      ),
      body: Container(
        child: Center(
          child:StaggeredGridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            primary: false,
            padding: const EdgeInsets.all(8),
            staggeredTiles: _staggeredTiles,
            children: _tiles,
            //            children: <Widget>[
//              Container(
//                child: Card(
//                  child: Column(
//                    children: <Widget>[
//                      Container(
//                        height: 100.0,
//                        width: 100.0,
//                        decoration: new BoxDecoration(
//                          image: DecorationImage(
//                            image: new AssetImage('assets/eyeit1.jpg'),
//                            fit: BoxFit.fill,
//                          ),
//                          shape: BoxShape.circle,
//                        ),
//                      ),
//                      Container(
//                        child: Padding(
//                          padding: const EdgeInsets.all(8.0),
//                          child: Row(
//                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                            children: <Widget>[
//                              Text("Purevision"),
//                              Text("\$ 10")
//                            ],
//                          ),
//                        )
//                      ),
//                      Divider(),
//                      RaisedButton(
//                        color: Colors.lightGreen,
//                        onPressed: (){
//
//                        },
//                        child: Container(
//                          width: MediaQuery.of(context).size.width/10,
//                          color: Colors.lightGreen,
//                          child: Center(child: Text('Add')),
//                        ),
//                      ),
//                    ],
//                  ),
//                ),
//              ),
////              Container(
////              child: Card(
////
////                child: Column(
////                  children: <Widget>[
////
////                      Container(
////                        height: MediaQuery.of(context).size.height/10,
////                        decoration: BoxDecoration(
////                          color: Colors.white,
////                          image: DecorationImage(
////                            fit: BoxFit.fitHeight,
////                            image: AssetImage('assets/eyeit1.jpg'),
////                          ),
////                          borderRadius: BorderRadius.circular(12),
////                        ),
////                      ),
////                      Container(
////                        height: MediaQuery.of(context).size.height/20,
////                        //color: Colors.black,
////                        child: Row(
////                          crossAxisAlignment: CrossAxisAlignment.center,
////                          children: <Widget>[
////
////                               Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Daily Lenses Disposable'),
////                              ),
////
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Price: 10 '),
////                              ),
////                            )
////                          ],
////                        ),
////
////                    ),
////                    Expanded(
////                      flex: 1,
////                      child: RaisedButton(
////                        color: Colors.lightGreen,
////                        onPressed: (){
////
////                        },
////                        child: Container(
////                          width: MediaQuery.of(context).size.width/10,
////                          color: Colors.lightGreen,
////                          child: Center(child: Text('Add')),
////                        ),
////                      ),
////                    ),
////                  ],
////                ),
////              ),
////              ),
////              Card(
////                child: Column(
////                  children: <Widget>[
////                    Expanded(
////                      flex:2,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/10,
////                        decoration: BoxDecoration(
////                          color: Colors.white,
////                          image: DecorationImage(
////                            fit: BoxFit.fitHeight,
////                            image: AssetImage('assets/eyeit2.jpg'),
////                          ),
////                          borderRadius: BorderRadius.circular(12),
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex:1,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/20,
////                        //color: Colors.black,
////                        child: Row(
////                          children: <Widget>[
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Purevision'),
////                              ),
////                            ),
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Price: 10 '),
////                              ),
////                            )
////                          ],
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex: 1,
////                      child: RaisedButton(
////                        color: Colors.lightGreen,
////                        onPressed: (){
////
////                        },
////                        child: Container(
////                          width: MediaQuery.of(context).size.width/10,
////                          color: Colors.lightGreen,
////                          child: Center(child: Text('Add')),
////                        ),
////                      ),
////                    ),
////                  ],
////                ),
////              ),
////              Card(
////                child: Column(
////                  children: <Widget>[
////                    Expanded(
////                      flex:2,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/10,
////                        decoration: BoxDecoration(
////                          color: Colors.white,
////                          image: DecorationImage(
////                            fit: BoxFit.fitHeight,
////                            image: AssetImage('assets/eyeit5.png'),
////                          ),
////                          borderRadius: BorderRadius.circular(12),
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex:1,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/20,
////                        //color: Colors.black,
////                        child: Row(
////                          children: <Widget>[
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Ultra contact lenses'),
////                              ),
////                            ),
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Price: 10 '),
////                              ),
////                            )
////                          ],
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex: 1,
////                      child: RaisedButton(
////                        color: Colors.lightGreen,
////                        onPressed: (){
////
////                        },
////                        child: Container(
////                          width: MediaQuery.of(context).size.width/10,
////                          color: Colors.lightGreen,
////                          child: Center(child: Text('Add')),
////                        ),
////                      ),
////                    ),
////                  ],
////                ),
////              ),
////              Card(
////                child: Column(
////                  children: <Widget>[
////                    Expanded(
////                      flex:2,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/10,
////                        decoration: BoxDecoration(
////                          color: Colors.white,
////                          image: DecorationImage(
////                            fit: BoxFit.fitHeight,
////                            image: AssetImage('assets/eyeit3.jpg'),
////                          ),
////                          borderRadius: BorderRadius.circular(12),
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex:1,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/20,
////                        //color: Colors.black,
////                        child: Row(
////                          children: <Widget>[
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Extended wear lenses'),
////                              ),
////                            ),
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Price: 10 '),
////                              ),
////                            )
////                          ],
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex: 1,
////                      child: RaisedButton(
////                        color: Colors.lightGreen,
////                        onPressed: (){
////
////                        },
////                        child: Container(
////                          width: MediaQuery.of(context).size.width/10,
////                          color: Colors.lightGreen,
////                          child: Center(child: Text('Add')),
////                        ),
////                      ),
////                    ),
////                  ],
////                ),
////              ),
////              Card(
////                child: Column(
////                  children: <Widget>[
////                    Expanded(
////                      flex:2,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/10,
////                        decoration: BoxDecoration(
////                          color:Colors.white,
////                          image: DecorationImage(
////                            fit: BoxFit.fitHeight,
////                            image: AssetImage('assets/eyeit4.jpg'),
////                          ),
////                          borderRadius: BorderRadius.circular(12),
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex:1,
////                      child: Container(
////                        height: MediaQuery.of(context).size.height/20,
////                        //color: Colors.black,
////                        child: Row(
////                          children: <Widget>[
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Daily Lenses Biotrue'),
////                              ),
////                            ),
////                            Expanded(
////                              flex:1,
////                              child: Container(
////                                width: MediaQuery.of(context).size.width/10,
////                                child: Text('Price: 10 '),
////                              ),
////                            )
////                          ],
////                        ),
////                      ),
////                    ),
////                    Expanded(
////                      flex: 1,
////                      child: RaisedButton(
////                        color: Colors.lightGreen,
////                        onPressed: (){
////
////                        },
////                        child: Container(
////                          width: MediaQuery.of(context).size.width/10,
////                          color: Colors.lightGreen,
////                          child: Center(child: Text('Add')),
////                        ),
////                      ),
////                    ),
////                  ],
////                ),
////              ),
//
//            ],
          ),
        ),
      ),
    );
  }
}

class _Example01Tile extends StatelessWidget {
  const _Example01Tile(this.backgroundColor, this.iconData);

  final Color backgroundColor;
  final IconData iconData;

  @override
  Widget build(BuildContext context) {
    return Container(
                child: Card(
                  elevation: 5,
                  child: Column(
                    children: <Widget>[
                      Container(
                        height: 100.0,
                        width: 100.0,
                        decoration: new BoxDecoration(
                          image: DecorationImage(
                            image: new AssetImage('assets/eyeit1.jpg'),
                            fit: BoxFit.fill,
                          ),
                          shape: BoxShape.circle,
                        ),
                      ),
                      Container(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text("Purevision"),
                              Text("\$ 10")
                            ],
                          ),
                        )
                      ),
                      Divider(),
                      RaisedButton(
                        color: Colors.lightGreen,
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>Cart_screen()));
                        },
                        child: Container(
                          width: MediaQuery.of(context).size.width/10,
                          color: Colors.lightGreen,
                          child: Center(child: Text('Add')),
                        ),
                      ),
                    ],
                  ),
                ),
              );
  }
}