import 'package:flutter/material.dart';
import 'package:kypropharmapp/CardCreditPage.dart';

class Patment extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => payment();
}

class Item {
  final String itemName;
  final String itemQun;
  final String itemPrice;

  Item({this.itemName, this.itemQun, this.itemPrice});
}

class payment extends State<Patment> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool checkboxValueA = true;
  bool checkboxValueB = false;
  bool checkboxValueC = false;

  IconData _backIcon() {
    switch (Theme.of(context).platform) {
      case TargetPlatform.android:
      case TargetPlatform.fuchsia:
        return Icons.arrow_back;
      case TargetPlatform.iOS:
        return Icons.arrow_back_ios;
    }
    assert(false);
    return null;
  }
  int radioValue = 0;
  void handleRadioValueChanged(int value) {
    setState(() {
      radioValue = value;

      print("BAA $value");
    });
  }

  List<Item> itemList = <Item>[
    Item(itemName: 'Black Grape', itemQun: 'Qty:1', itemPrice: '\€ 100'),
    Item(itemName: 'Tomato', itemQun: 'Qty:3', itemPrice: '\€ 112'),
    Item(itemName: 'Mango', itemQun: 'Qty:2', itemPrice: '\€ 105'),
    Item(itemName: 'Capsicum', itemQun: 'Qty:1', itemPrice: '\€ 90'),
    Item(itemName: 'Lemon', itemQun: 'Qty:2', itemPrice: '\€ 70'),
    Item(itemName: 'Apple', itemQun: 'Qty:1', itemPrice: '\€ 50'),
  ];
  String toolbarname = 'CheckOut';

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    final double height = MediaQuery.of(context).size.height;

    AppBar appBar = AppBar(
      leading: IconButton(
        icon: Icon(_backIcon()),
        alignment: Alignment.centerLeft,
        color: Colors.green,
        tooltip: 'Back',
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(toolbarname,style: TextStyle(color: Colors.green),),
      backgroundColor: Colors.white,
      actions: <Widget>[
        new Padding(
          padding: const EdgeInsets.all(10.0),
          child: new Container(
            height: 150.0,
            width: 30.0,
            child: new GestureDetector(
              onTap: () {
                /*Navigator.of(context).push(
                  new MaterialPageRoute(
                      builder:(BuildContext context) =>
                      new CartItemsScreen()
                  )
              );*/
              },
            ),
          ),
        )
      ],
    );

    return new Scaffold(
      key: _scaffoldKey,
      appBar: appBar,
      body: Container(
        decoration: BoxDecoration(
        image: DecorationImage(
        image: AssetImage("assets/simple_back.jpg"),
        fit: BoxFit.cover
        ) ,
      ),
        child: Column(
          children: <Widget>[
            Expanded(
               child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints viewportConstraints) {
                      return SingleChildScrollView(
                        child:  Column(
                          children: <Widget>[

                            Container(
                                height: MediaQuery.of(context).size.height /4,
                            ),
                            _verticalDivider(),
//                          Container(
//                              margin: EdgeInsets.all(10.0),
//                              child: Card(
//                                child: Container(
//                                  color: Colors.green.shade100,
//                                  child: Container(
//                                      padding:
//                                          const EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 15.0),
//                                      child: Text(
//                                          "GET EXTRA 5% OFF* with MONEY bank Simply Save Credit card. T&C.",
//                                          maxLines: 10,
//                                          style: TextStyle(
//                                              fontSize: 13.0, color: Colors.black87))),
//                                ),
//                              )
//                          ),

                          new Container(
                            alignment: Alignment.topLeft,
                            margin:
                                EdgeInsets.only(left: 12.0, top: 5.0, right: 0.0, bottom: 5.0),
                            child: new Text(
                              'Payment Method',
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 28.0),
                            ),
                          ),

                              _verticalDivider(),

                          new Container(
                             // height: 264.0,
                              margin: EdgeInsets.all(10.0),
                            //  child: Card(
                                child: Container(
                                  child: Container(
                                      child: Column(
                                    children: <Widget>[
                                      _verticalD(),
                                      Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 60,
                                        child: Card(
                                          elevation: 10,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: <Widget>[
                                              Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Text("Credit Card",
                                                    maxLines: 10,
                                                    style: TextStyle(
                                                        fontSize: 15.0, color: Colors.black, fontWeight: FontWeight.bold)),
                                              ),
                                              Radio<int>(
                                                activeColor: Colors.lightGreen,
                                                  value: 0,
                                                  groupValue: radioValue,
                                                  onChanged: handleRadioValueChanged),
                                            ],
                                          )
                                        ),
                                      ),
                                       Divider(),
                                      _verticalD(),
                                      Container(
                                        width: MediaQuery.of(context).size.width,
                                        height: 60,
                                        child: Card(
                                            elevation: 10,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: <Widget>[
                                                Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Text("Google Pay",
                                                      maxLines: 10,
                                                      style: TextStyle(
                                                          fontSize: 15.0, color: Colors.black, fontWeight: FontWeight.bold)),
                                                ),
                                                Radio<int>(
                                                    activeColor: Colors.lightGreen,
                                                    value: 1,
                                                    groupValue: radioValue,
                                                    onChanged: handleRadioValueChanged),
                                              ],
                                            )
                                        ),
                                      ),
                                    ],
                                  )
                                  ),
                                ),
                              //)
                          ),
                          ]

                            ),
                          );
                      },
               ),
            ),


            Container(
              //color: Colors.white.withOpacity(0.8),)
              //alignment: Alignment.bottomLeft,
              height: 60.0,
              width:  MediaQuery.of(context).size.width,
              child: Card(
                elevation: 10,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    //IconButton(icon: Icon(Icons.info), onPressed: null),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Total :',
                        style: TextStyle(
                            fontSize: 17.0,
                            color: Colors.black,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    Text(
                      '\€ 524',
                      style: TextStyle(fontSize: 17.0, color: Colors.black54),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        alignment: Alignment.center,
                        child: OutlineButton(
                            borderSide:
                            BorderSide(color: Colors.green.shade500),
                            child: const Text('PROCEED PAYMENT'),
                            textColor: Colors.green.shade500,
                            onPressed: () {
                              print(radioValue);
                              if(radioValue == 0){
                                    Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                    builder: (context) => CardCreditPage()));
                                  }else{
                                    Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => CardCreditPage()));
                                  }
                              },
                            shape: new OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                            )),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    ],
    ),
    ),
    );

//
//
  }

  _verticalDivider() => Container(
        padding: EdgeInsets.all(2.0),
      );

  _verticalD() => Container(
        margin: EdgeInsets.only(left: 5.0),
      );
}
