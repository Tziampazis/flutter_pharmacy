import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:kypropharmapp/drugsScreen.dart';
import 'babyCareScreen.dart';
import 'eyeCareScreen.dart';
import 'settingsScreen.dart';
import 'package:google_fonts/google_fonts.dart';
import 'Cart_Screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Φαρμακείο',
      home: MyHomePage(title: 'Φαρμακείο Online'),
      initialRoute: MyHomePage.id,
      routes: {
        babyCareScreen.id: (context) => babyCareScreen(),
        eyeCareScreen.id: (context) => eyeCareScreen(),
        drugsScreen.id: (context) => drugsScreen(),
        settingsScreen.id: (context) => settingsScreen()
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  static const String id = 'home_screen';

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            new Card(
              color: Colors.lightGreen,
              child: UserAccountsDrawerHeader(
                accountName: new Text("Georgios Hadjigeorgiou"),
                accountEmail: new Text("giorgos.h4@gmail.com"),
                onDetailsPressed: () {},
                decoration: new BoxDecoration(
                  backgroundBlendMode: BlendMode.color,
                  color: Colors.lightGreen,

                  /* image: new DecorationImage(
               //   image: new ExactAssetImage('assets/images/lake.jpeg'),
                  fit: BoxFit.cover,
                ),*/
                ),
                currentAccountPicture: CircleAvatar(
                    backgroundImage: NetworkImage(
                        "https://www.fakenamegenerator.com/images/sil-male.png")),
              ),
            ),
            new Card(
              elevation: 4.0,
              child: new Column(
                children: <Widget>[
                  new ListTile(
                      leading: Icon(Icons.favorite),
                      title: new Text('Favorite'),
                      onTap: () {}),
                  new Divider(),
                  new ListTile(
                      leading: Icon(Icons.history),
                      title: new Text("Order History "),
                      onTap: () {}),
                ],
              ),
            ),
            new Card(
              elevation: 4.0,
              child: new Column(
                children: <Widget>[
                  new ListTile(
                      leading: Icon(Icons.settings),
                      title: new Text("Setting"),
                      onTap: () {
                        Navigator.pushNamed(context, settingsScreen.id);
                      }),
                  new Divider(),
                  new ListTile(
                      leading: Icon(Icons.help),
                      title: new Text("Help"),
                      onTap: () {}),
                ],
              ),
            ),
            new Card(
              elevation: 4.0,
              child: new ListTile(
                  leading: Icon(Icons.power_settings_new,color: Colors.lightGreen),
                  title: new Text(
                    "Logout",
                    style:
                    new TextStyle(color: Colors.lightGreen, fontSize: 17.0),
                  ),
                  onTap: () {}),
            )
          ],
        ),
      ),
      appBar: AppBar(
          title: Text(widget.title,style: TextStyle(color: Colors.lightGreen),),
        backgroundColor: Colors.white,
        iconTheme: new IconThemeData(color: Colors.green),
          actions: <Widget>[
            IconButton(
              icon: Icon(Icons.shopping_cart,color: Colors.lightGreen,),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Cart_screen()));
              }
            ),
          ],
        ),
     body:  Container(
            decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("assets/simple_back.jpg"),
                        fit: BoxFit.cover
                    ),
            ),
      child: new  LayoutBuilder(
            builder: (BuildContext context, BoxConstraints viewportConstraints) {
          return SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                //minHeight: viewportConstraints.maxHeight,
              ),
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget> [
                    Container(
                      padding: EdgeInsets.all(7.0),
                      alignment: Alignment.topLeft,
                      child: RichText(
                        text: TextSpan(
                          children: <TextSpan>[
                            TextSpan(
                                text: 'Popular Brands',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'RobotoMono',
                                )),
                          ],
                        ),
                      ),
                    ),
                      verticalDivider(),
                    Container(
                      height: 130,
                      child: _buildListBrand(100),
                    ),
                    verticalDivider(),
                    Container(
                    padding: EdgeInsets.all(8.0),
                    alignment: Alignment.topLeft,
                      child: RichText(
                         text: TextSpan(
                             children: <TextSpan>[
                                TextSpan(
                                   text: 'Categories',
                                   style: TextStyle(
                                   color: Colors.black,
                                   fontSize: 25,
                                   fontWeight: FontWeight.bold,
                                     fontFamily: 'RobotoMono',
                                    )),
                                    ],
                                  ),
                                ),
                              ),
                      Container(
                        height: 800,
                        child: GridView.count(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 10,
                                    mainAxisSpacing: 15,
                                    primary: false,
                                    padding: const EdgeInsets.all(8),
                                    children: <Widget>[
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pushNamed(context, drugsScreen.id);
                                        },
                                        child: Card(
                                          elevation: 8,
                                          child: Container(
                                            padding: EdgeInsets.all(5.0),
                                            alignment: Alignment.bottomLeft,
                                            // color: Colors.black38,
                                            //child: Center(
                                            child: RichText(
                                              text: TextSpan(
                                                children: <TextSpan>[
                                                  TextSpan(
                                                      text: 'Φάρμακα',
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 20,
                                                        fontWeight: FontWeight.bold,
                                                      )),
                                                ],
                                              ),
                                            ),
                                            //),
                                            decoration: BoxDecoration(
                                              // color: Colors.lightGreen,
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage('assets/medicines.jpg'),
                                                  colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
                                              ),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pushNamed(context, babyCareScreen.id);
                                        },
                                        child: Card(
                                          elevation: 8,
                                          child: Container(
                                            padding: EdgeInsets.all(5.0),
                                            alignment: Alignment.bottomLeft,
                                            //child: Center(
                                            child: Text(
                                              'Baby Care',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            //  ),
                                            decoration: BoxDecoration(
                                              // color: Colors.lightGreen,
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage('assets/Baby-Care-2.jpg'),
                                                  colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
                                              ),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Card(
                                        elevation: 8,
                                        child: Container(
                                          padding: EdgeInsets.all(5.0),
                                          alignment: Alignment.bottomLeft,
                                          // child: Center(
                                          child: Text(
                                            'Food Supplements',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                            ),

                                          ),
                                          //  ),
                                          decoration: BoxDecoration(
                                            //color: Colors.lightGreen,
                                            image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage('assets/supplements.jpg'),
                                                colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
                                            ),
                                            borderRadius: BorderRadius.circular(5),
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pushNamed(context, eyeCareScreen.id);
                                        },
                                        child: Card(
                                          elevation: 8,
                                          child: Container(
                                            padding: EdgeInsets.all(5.0),
                                            alignment: Alignment.bottomLeft,
                                            //child: Center(
                                            child: Text(
                                              'Eye care',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            // ),
                                            decoration: BoxDecoration(
                                              //color: Colors.lightGreen,
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage('assets/Eye-Care.jpeg'),
                                                  colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
                                              ),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Navigator.pushNamed(context, eyeCareScreen.id);
                                        },
                                        child: Card(
                                          elevation: 8,
                                          child: Container(
                                            padding: EdgeInsets.all(5.0),
                                            alignment: Alignment.bottomLeft,
                                            //child: Center(
                                            child: Text(
                                              'Eye care',
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            // ),
                                            decoration: BoxDecoration(
                                              //color: Colors.lightGreen,
                                              image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage('assets/Eye-Care.jpeg'),
                                                  colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
                                              ),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Card(
                                        elevation: 8,
                                        child:Container(
                                          padding: EdgeInsets.all(5.0),
                                          alignment: Alignment.bottomLeft,
                                          child: RichText(
                                            text: TextSpan(
                                              children: <TextSpan>[
                                                TextSpan(
                                                  text: 'Συμπληρώματα Διατροφής ',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          decoration: BoxDecoration(
                                            // color: const Color(0xff7c94b6),
                                            image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage('assets/astragalus.jpeg'),
                                                colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
                                            ),
                                            borderRadius: BorderRadius.circular(5),
                                          ),
                                        ),
                                      ),
                                      Card(
                                        //color: Colors.lightGreen,
                                        child: Column(
                                          children: <Widget>[
                                            Expanded(
                                                flex: 1,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      image: AssetImage('assets/naturalhealth.jpeg'),

                                                    ),
                                                  ),
                                                )
                                            ),
//                                            Expanded(
//                                              flex: 1,
//                                              child: RichText(
//                                                text: TextSpan(
//                                                  children: <TextSpan>[
//                                                    TextSpan(
//                                                        text: 'Natural Health',
//                                                        style: TextStyle(
//                                                          color: Colors.black,
//                                                          fontSize: 30,
//                                                        )),
//                                                  ],
//                                                ),
//                                              ),
//                                            ),
                                          ],
                                        ),
                                      ),
                            ]))

                    ])));}))
      ,);}}

//
//                    Container(
////        decoration: BoxDecoration(
////            image: DecorationImage(
////                image: AssetImage("assets/back_last.jpg"),
////                fit: BoxFit.cover
////            )
////        ),



verticalDivider() =>
    Container(
      padding: EdgeInsets.all(2.0),
    );

Widget _buildListBrand(double width) {
  return ListView(
      scrollDirection: Axis.horizontal,
      padding: EdgeInsets.all(2),
      children: <Widget>[
        Card(
          elevation: 5,
          child: Container(
            width: width,
            //color: Colors.deepOrange,

            child: Image.asset(
              'assets/med1.jpeg',
              fit: BoxFit.fitWidth,
            ),
          ),
        ),
       // Divider(),
        Container(
          width: 10,
        ),
        Card(
          elevation: 5,
          child: Container(
            width: width,
            //color: Colors.deepOrange,

            child: Image.asset(
              'assets/babyitem.png',
              fit: BoxFit.fitWidth,
            ),
          ),
        ),
        Container(
          width: 10,
        ),
        Card(
          elevation: 5,
          child: Container(
            width: width,
            child: Image.asset(
              'assets/lenses.jpg',
              fit: BoxFit.fitWidth,
            ),
          ),
        ),
        Container(
          width: 10,
        ),
        Card(
          elevation: 5,
          child: Container(
            width: width,
            child: Image.asset(
              'assets/med2.jpeg',
              fit: BoxFit.fitWidth,
            ),
          ),
        ),
      ]);
}

Widget _buildListCategories() {
  return GridView.count(
    primary: false,
    padding: const EdgeInsets.all(10),
    children: <Widget>[],
  );
}




































//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:kypropharmapp/Cart_Screen.dart';
//import 'package:kypropharmapp/drugsScreen.dart';
//import 'babyCareScreen.dart';
//import 'eyeCareScreen.dart';
//import 'settingsScreen.dart';
//import 'package:google_fonts/google_fonts.dart';
//import 'package:flutter_icons/flutter_icons.dart';
//
//void main() => runApp(MyApp());
//
//class MyApp extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    return MaterialApp(
//      title: 'Φαρμακείο',
//      theme: ThemeData(
//        primarySwatch: Colors.green,
//      ),
//      home: MyHomePage(title: 'Φαρμακείο Online'),
//      initialRoute: MyHomePage.id,
//      routes: {
//        babyCareScreen.id: (context) => babyCareScreen(),
//        eyeCareScreen.id: (context) => eyeCareScreen(),
//        drugsScreen.id: (context) => drugsScreen(),
//        settingsScreen.id: (context) => settingsScreen(),
//        Cart_screen.id:(context) => Cart_screen(),
//
//      },
//    );
//  }
//}
//
//class MyHomePage extends StatefulWidget {
//  MyHomePage({Key key, this.title}) : super(key: key);
//  static const String id = 'home_screen';
//
//  final String title;
//
//  @override
//  _MyHomePageState createState() => _MyHomePageState();
//}
//
//class _MyHomePageState extends State<MyHomePage> {
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      backgroundColor: Colors.white,
//      drawer: Drawer(
//        child: ListView(
//          children: <Widget>[
//            new Card(
//              child: UserAccountsDrawerHeader(
//                accountName: new Text("Georgios Hadjigeorgiou"),
//                accountEmail: new Text("giorgos.h4@gmail.com"),
//                onDetailsPressed: () {},
//                decoration: new BoxDecoration(
//                  backgroundBlendMode: BlendMode.difference,
//                  color: Colors.white30,
//
//                  /* image: new DecorationImage(
//               //   image: new ExactAssetImage('assets/images/lake.jpeg'),
//                  fit: BoxFit.cover,
//                ),*/
//                ),
//                currentAccountPicture: CircleAvatar(
//                    backgroundImage: NetworkImage(
//                        "https://www.fakenamegenerator.com/images/sil-male.png")),
//              ),
//            ),
//            new Card(
//              elevation: 4.0,
//              child: new Column(
//                children: <Widget>[
//                  new ListTile(
//                      leading: Icon(Icons.favorite),
//                      title: new Text('Favorite'),
//                      onTap: () {}),
//                  new Divider(),
//                  new ListTile(
//                      leading: Icon(Icons.history),
//                      title: new Text("Order History "),
//                      onTap: () {}),
//                ],
//              ),
//            ),
//            new Card(
//              elevation: 4.0,
//              child: new Column(
//                children: <Widget>[
//                  new ListTile(
//                      leading: Icon(Icons.settings),
//                      title: new Text("Setting"),
//                      onTap: () {
//                        Navigator.pushNamed(context, settingsScreen.id);
//                      }),
//                  new Divider(),
//                  new ListTile(
//                      leading: Icon(Icons.help),
//                      title: new Text("Help"),
//                      onTap: () {}),
//                ],
//              ),
//            ),
//            new Card(
//              elevation: 4.0,
//              child: new ListTile(
//                  leading: Icon(Icons.power_settings_new),
//                  title: new Text(
//                    "Logout",
//                    style:
//                        new TextStyle(color: Colors.redAccent, fontSize: 17.0),
//                  ),
//                  onTap: () {}),
//            )
//          ],
//        ),
//      ),
//      appBar: AppBar(
//        title: Text(widget.title),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(Icons.shopping_cart),
//            color: Colors.white,
//            onPressed: () {
//              Navigator.push(context, MaterialPageRoute(builder: (context)=>Cart_screen()));
//            }
//          ),
//        ],
//      ),
//      body: Container(
//        decoration: BoxDecoration(
//            image: DecorationImage(
//                image: AssetImage("assets/back_last.jpg"),
//                fit: BoxFit.cover
//            )
//        ),
//        child: Center(
//          child: Stack(
//            children: <Widget>[
//              Positioned(
//                top: MediaQuery.of(context).size.height / 50,
//                child: SizedBox(
//                  height: MediaQuery.of(context).size.height / 4,
//                  width: MediaQuery.of(context).size.width,
//                  child: RichText(
//                    text: TextSpan(
//                      children: <TextSpan>[
//                        TextSpan(
//                            text: 'Popular Brands',
//                            style: TextStyle(
//                              color: Colors.black,
//                              fontSize: 30,
//                            )),
//                      ],
//                    ),
//                  ),
//                ),
//              ),
//              Positioned(
//                top: MediaQuery.of(context).size.height / 15,
//                child: SizedBox(
//                  height: MediaQuery.of(context).size.height / 4,
//                  width: MediaQuery.of(context).size.width,
//                  child: _buildListBrand(150),
//                ),
//              ),
//              Positioned(
//                top: MediaQuery.of(context).size.height / 3,
//                child: Container(
//                  padding: EdgeInsets.all(8.0),
//                  child: RichText(
//                    text: TextSpan(
//                      children: <TextSpan>[
//                        TextSpan(
//                            text: 'Categories',
//                              style: TextStyle(
//                                color: Colors.black54,
//                                fontSize: 30,
//                                fontWeight: FontWeight.bold,
//
//                            )),
//                      ],
//                    ),
//                  ),
//                ),
//              ),
//              Positioned(
//                top: MediaQuery.of(context).size.height / 2.5,
//                child: SizedBox(
//                  height: MediaQuery.of(context).size.height / 2,
//                  width: MediaQuery.of(context).size.width,
//                  child: Container(
//                    child: GridView.count(
//                      crossAxisCount: 2,
//                      crossAxisSpacing: 10,
//                      mainAxisSpacing: 10,
//                      primary: false,
//                      padding: const EdgeInsets.all(8),
//                      children: <Widget>[
//                        GestureDetector(
//                          onTap: () {
//                            Navigator.pushNamed(context, drugsScreen.id);
//                          },
//                          child: Card(
//                            elevation: 8,
//                           child: Container(
//                             padding: EdgeInsets.all(5.0),
//                            alignment: Alignment.bottomLeft,
//                           // color: Colors.black38,
//                            //child: Center(
//                              child: RichText(
//                                text: TextSpan(
//                                  children: <TextSpan>[
//                                    TextSpan(
//                                        text: 'Φάρμακα',
//                                        style: TextStyle(
//                                          color: Colors.white,
//                                          fontSize: 20,
//                                          fontWeight: FontWeight.bold,
//                                        )),
//                                  ],
//                                ),
//                              ),
//                            //),
//                            decoration: BoxDecoration(
//                             // color: Colors.lightGreen,
//                              image: DecorationImage(
//                                fit: BoxFit.cover,
//                                image: AssetImage('assets/medicines.jpg'),
//                                colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
//                              ),
//                              borderRadius: BorderRadius.circular(5),
//                            ),
//                          ),
//                          ),
//                        ),
//                        GestureDetector(
//                          onTap: () {
//                            Navigator.pushNamed(context, babyCareScreen.id);
//                          },
//                          child: Container(
//                            padding: EdgeInsets.all(5.0),
//                            alignment: Alignment.bottomLeft,
//                            //child: Center(
//                            child: Text(
//                              'Baby Care',
//                                style: TextStyle(
//                                          color: Colors.white,
//                                          fontSize: 20,
//                                          fontWeight: FontWeight.bold,
//                                        ),
//                            ),
//                            //  ),
//                            decoration: BoxDecoration(
//                              // color: Colors.lightGreen,
//                              image: DecorationImage(
//                                  fit: BoxFit.cover,
//                                  image: AssetImage('assets/Baby-Care-2.jpg'),
//                                  colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
//                              ),
//                              borderRadius: BorderRadius.circular(12),
//                            ),
//                          ),
//                        ),
//                        Container(
//                          padding: EdgeInsets.all(5.0),
//                          alignment: Alignment.bottomLeft,
//                         // child: Center(
//                            child: Text(
//                              'Food Supplements',
//                              style: TextStyle(
//                                color: Colors.white,
//                                fontSize: 20,
//                                fontWeight: FontWeight.bold,
//                              ),
//
//                            ),
//                        //  ),
//                          decoration: BoxDecoration(
//                            //color: Colors.lightGreen,
//                            image: DecorationImage(
//                              fit: BoxFit.cover,
//                              image: AssetImage('assets/supplements.jpg'),
//                                colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
//                            ),
//                            borderRadius: BorderRadius.circular(12),
//                          ),
//                        ),
//                        Container(
//                          padding: EdgeInsets.all(5.0),
//                          alignment: Alignment.bottomLeft,
//                          child: RichText(
//                            text: TextSpan(
//                              children: <TextSpan>[
//                                TextSpan(
//                                    text: 'Συμπληρώματα Διατροφής ',
//                                  style: TextStyle(
//                                    color: Colors.white,
//                                    fontSize: 20,
//                                    fontWeight: FontWeight.bold,
//                                  ),
//                                ),
//                              ],
//                            ),
//                          ),
//                          decoration: BoxDecoration(
//                           // color: const Color(0xff7c94b6),
//                            image: DecorationImage(
//                              fit: BoxFit.cover,
//                              image: AssetImage('assets/astragalus.jpeg'),
//                                colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
//                            ),
//                            borderRadius: BorderRadius.circular(12),
//                          ),
//                        ),
//                        Container(
//                          padding: EdgeInsets.all(5.0),
//                          alignment: Alignment.bottomLeft,
//                          //child: Center(
//                            child: Text(
//                              'Eye care',
//                              style: TextStyle(
//                                color: Colors.white,
//                                fontSize: 20,
//                                fontWeight: FontWeight.bold,
//                              ),
//                            ),
//                         // ),
//                          decoration: BoxDecoration(
//                            //color: Colors.lightGreen,
//                          image: DecorationImage(
//                            fit: BoxFit.cover,
//                            image: AssetImage('assets/Eye-Care.jpeg'),
//                              colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.2), BlendMode.darken)
//                          ),
//                            borderRadius: BorderRadius.circular(12),
//                          ),
//                        ),
//                        GestureDetector(
//                          onTap: () {
//                            Navigator.pushNamed(context, eyeCareScreen.id);
//                          },
//                          child: Container(
//                              child: Card(
//                                color: Colors.lightGreen,
//                                child: Column(
//                                  children: <Widget>[
//                                    Icon( FontAwesome5.eye,
//                                    ),
//                                  ],
//                                ),
//                              )
//                          ),
//                        ),
//                      ],
//                    ),
//                  ),
//                ),
//              ),
//            ],
//          ),
//        ),
//      ),
//    );
//  }
//}
//
//Widget _buildListBrand(double width) {
//  return ListView(
//      scrollDirection: Axis.horizontal,
//      padding: EdgeInsets.all(2),
//      children: <Widget>[
//        Card(
//          child: Container(
//            width: width,
//            //color: Colors.deepOrange,
//
//            child: Image.asset(
//              'assets/bauschLombLogoHome.jpg',
//              fit: BoxFit.fitWidth,
//            ),
//          ),
//        ),
//        Divider(),
//        Card(
//          child: Container(
//            width: width,
//            //color: Colors.deepOrange,
//
//            child: Image.asset(
//              'assets/rayner.png',
//              fit: BoxFit.fitWidth,
//            ),
//          ),
//        ),
//        Divider(),
//        Card(
//          child: Container(
//            width: width,
//            child: Image.asset(
//              'assets/altacare-lab.png',
//              fit: BoxFit.fitWidth,
//            ),
//          ),
//        ),
//      ]);
//}
//
//Widget _buildListCategories() {
//  return GridView.count(
//    primary: false,
//    padding: const EdgeInsets.all(10),
//    children: <Widget>[],
//  );
//}
